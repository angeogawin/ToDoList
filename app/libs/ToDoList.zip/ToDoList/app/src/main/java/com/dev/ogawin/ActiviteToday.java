package com.dev.ogawin;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.dev.ogawin.databasehelper.MyDatabaseHelper;
import com.dev.ogawin.databinding.ActiviteTodayBinding;
import com.dev.ogawin.databinding.ActivityMainBinding;
import com.dev.ogawin.model.Rappel;

import java.util.ArrayList;
import java.util.List;

public class ActiviteToday extends AppCompatActivity {

    private ActiviteTodayBinding binding;

    private final List<Rappel> rappelList = new ArrayList<Rappel>();
    MyListAdapter adapter;
    MyDatabaseHelper db;
    ListView list;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        binding = ActiviteTodayBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        db = MyDatabaseHelper.getInstanceDb((this));
        List<Rappel> listRap=  db.getTodayRappels();
        this.rappelList.addAll(listRap);

        TextView textView = new TextView(this);
        textView.setText("Aujourd'hui");
        textView.setTextSize(36);
        textView.setTextColor(Color.BLUE);

        adapter=new MyListAdapter(this, rappelList);
        list=(ListView)findViewById(R.id.list);
        list.addHeaderView(textView);
        list.setAdapter(adapter);


        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(getBaseContext(), ActiviteCreerRappel.class);
                //myIntent.putExtra("key", value); //Optional parameters
                ActiviteToday.this.startActivityForResult(myIntent,0);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);

            if (resultCode  == RESULT_OK) {

                //New rappel has been added
                //Refresh listview
                //adapter.clear();
               // adapter.addAll(db.getAllRappels());
                //((MyListAdapter) list.getAdapter()).notifyDataSetChanged();
            }
        } catch (Exception ex) {

        }

    }

}