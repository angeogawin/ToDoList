package com.dev.ogawin;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import com.dev.ogawin.databasehelper.MyDatabaseHelper;
import com.dev.ogawin.databinding.ActiviteToutBinding;
import com.dev.ogawin.model.Rappel;
import com.hudomju.swipe.SwipeToDismissTouchListener;
import com.hudomju.swipe.adapter.ListViewAdapter;


import java.util.ArrayList;
import java.util.List;

import static com.dev.ogawin.databasehelper.MyDatabaseHelper.getInstanceDb;


public class ActiviteTout extends AppCompatActivity {

    private ActiviteToutBinding binding;
    ListView list;
    private final List<Rappel> rappelList = new ArrayList<Rappel>();
    MyListAdapter adapter;
    MyDatabaseHelper db;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        binding = ActiviteToutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = MyDatabaseHelper.getInstanceDb((this));
        List<Rappel> listRap=  db.getAllRappels();
        this.rappelList.addAll(listRap);

        TextView textView = new TextView(this);
        textView.setText("Rappels");
        textView.setTextSize(36);
        textView.setTextColor(Color.BLUE);

        adapter=new MyListAdapter(this, rappelList);
        list=(ListView)findViewById(R.id.list);
        list.addHeaderView(textView);



        // Set the SwipeActionAdapter as the Adapter for your ListView
        list.setAdapter(adapter);

        final SwipeToDismissTouchListener<ListViewAdapter> touchListener =
                new SwipeToDismissTouchListener<>(
                        new ListViewAdapter(list),
                        new SwipeToDismissTouchListener.DismissCallbacks<ListViewAdapter>() {
                            @Override
                            public boolean canDismiss(int position) {
                                return true;
                            }

                            @Override
                            public void onDismiss(ListViewAdapter view, int position) {
                                adapter.remove(position);
                            }
                        });

        // Dismiss the item automatically after 3 seconds
        //touchListener.setDismissDelay(3000);
        list.setOnTouchListener(touchListener);
        list.setOnScrollListener((AbsListView.OnScrollListener) touchListener.makeScrollListener());
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (touchListener.existPendingDismisses()) {
                    touchListener.undoPendingDismiss();
                } else {

                    //Toast.makeText(ActiviteTout.this, "Position " + position, LENGTH_SHORT).show();
                }
            }
        });




        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(getBaseContext(), ActiviteCreerRappel.class);
                //myIntent.putExtra("key", value); //Optional parameters
                ActiviteTout.this.startActivityForResult(myIntent,0);
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);

            if (resultCode  == RESULT_OK) {

                //New rappel has been added
                //Refresh listview
                adapter.refresh();
            }
        } catch (Exception ex) {

        }

    }

}