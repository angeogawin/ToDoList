package com.dev.ogawin;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.dev.ogawin.databasehelper.MyDatabaseHelper;
import com.dev.ogawin.model.Rappel;

import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import java.text.SimpleDateFormat;
import java.util.List;

public class MyListAdapter extends BaseAdapter {

    private final Context context;

    MyDatabaseHelper db;

    private List<Rappel> rappelList;
    public MyListAdapter(Context context,  List<Rappel> rappelList) {


        this.context=context;
        this.rappelList = rappelList;

        db = MyDatabaseHelper.getInstanceDb(context);
    }

    public void remove(int position) {
        db.deleteRappel((Rappel) this.getItem(position-1));

        rappelList.remove(position-1);
        notifyDataSetChanged();
    }
    public void refresh() {
        rappelList.clear();
        rappelList.addAll(db.getAllRappels());
        notifyDataSetChanged();
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }
    @Override
    public int getItemViewType(int position) {

        return position;
    }

    @Override
    public int getCount() {
        return rappelList.size();
    }

    @Override
    public Object getItem(int position) {
        return rappelList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater=(LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView=inflater.inflate(R.layout.mylist, null,true);

        TextView titleText = (TextView) rowView.findViewById(R.id.title);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
        TextView subtitleText = (TextView) rowView.findViewById(R.id.subtitle);

        titleText.setText(rappelList.get(position).getRappelTitle());
        subtitleText.setText(String.valueOf(parseRappelDate(rappelList.get(position).getRappelDate())) + " " +
                String.valueOf(parseRappelTime(rappelList.get(position).getRappelTime())) + ", " +
                rappelList.get(position).getRappelRecurrence());

        return rowView;

    };

    public String parseRappelTime(LocalTime rappelTime)
    {

        String resultat = rappelTime.toString("HH:mm");

        return resultat;
    }

    public String parseRappelDate(LocalDate rappelDate)
    {
        String resultat = rappelDate.toString("dd-MM-yyyy");

        LocalDate now = LocalDate.now();
        String nowS = now.toString("dd-MM-yyyy");
        String nowPlusOneDay = now.plusDays(1).toString("dd-MM-yyyy");
        String nowPlusTwoDay = now.plusDays(2).toString("dd-MM-yyyy");
        String nowMinusOneDay = now.minusDays(1).toString("dd-MM-yyyy");
        String nowMinusTwoDay = now.minusDays(2).toString("dd-MM-yyyy");

        if(nowS.equals(resultat))
        {
            //Rappel is today
            resultat = "aujourd'hui";
        }
        else if(nowPlusOneDay.equals(resultat))
        {
            //Rappel is tomorrow
            resultat = "demain";
        }
        else if(nowMinusOneDay.equals(resultat))
        {
            //Rappel was yesterday
            resultat= "hier";
        }
        else if(nowMinusTwoDay.equals(resultat))
        {
            //Rappel was before yesterday
            resultat= "avant-hier";
        }
        else if(nowPlusTwoDay.equals(resultat))
        {
            //Rappel is after tomorrow
            resultat= "après-demain";
        }


        return resultat;
    }
}