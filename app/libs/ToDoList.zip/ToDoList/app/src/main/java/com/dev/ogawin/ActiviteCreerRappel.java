package com.dev.ogawin;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

import com.dev.ogawin.databasehelper.MyDatabaseHelper;
import com.dev.ogawin.databinding.ActiviteCreerRappelBinding;
import com.dev.ogawin.model.Rappel;

import org.joda.time.LocalDate;
import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class ActiviteCreerRappel extends AppCompatActivity {
    private ActiviteCreerRappelBinding binding;

    Button bAnnulerCreation, bOk;
    EditText etTitre,etNotes;
    CalendarView cvDate;
    TimePicker tpTime;
    Spinner spPriorite,spRecurrence;
    TextView tvDateSelected,tvTimeSelected;

    MyDatabaseHelper db ;
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        binding = ActiviteCreerRappelBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = new MyDatabaseHelper(getBaseContext());

        bAnnulerCreation= findViewById(R.id.cancelButton);
        bOk= findViewById(R.id.proceedButton);
        etTitre = findViewById(R.id.titre);
        etNotes = findViewById(R.id.notes);
        cvDate = findViewById(R.id.date);
        tpTime = findViewById(R.id.time);
        spPriorite= findViewById(R.id.priorite);
        spRecurrence = findViewById(R.id.recurrence);

        tvDateSelected = findViewById(R.id.textview_selecteddate);
        tvTimeSelected = findViewById(R.id.textview_selectedtime);

        //If a title is specified, 'OK' button becomes clickable
        //if no title is psecified, 'OK' button become non clickable
        etTitre.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {

                if (!"".equals(etTitre.getText())) {
                    bOk.setClickable(true);
                }
                else
                {
                    bOk.setClickable(false);
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });

        // handle the PROCEED button
        bOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //At least a title should be specified before creation of a 'rappel'
                String titre = etTitre.getText().toString();
                if (!"".equals(titre)) {

                    //Store 'rappel in database'
                    String notes = etNotes.getText().toString();
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    LocalDate rappelDate =LocalDate.parse(format.format(new Date(cvDate.getDate())));
                    String hour = String.valueOf(tpTime.getHour());
                    String minute = String.valueOf(tpTime.getMinute());
                    DateTimeFormatter fmt = DateTimeFormat.forPattern("HH:mm");
                    LocalTime rappelTime =fmt.parseLocalTime(hour+ ":" + minute);
                    String recurrence = spRecurrence.getSelectedItem().toString();
                    LocalDate dateFinRecurrence =null;
                    String priorite = spPriorite.getSelectedItem().toString();
                    List<String> rappelIdsSousTaches = new ArrayList<>();
                    Rappel newRappel = new Rappel(titre,notes,rappelDate,rappelTime,recurrence,dateFinRecurrence,priorite,rappelIdsSousTaches);
                    db.addRappel(newRappel);

                    //We terminate the activity for 'rappel' creation
                    setResult(RESULT_OK);
                    finish();
                }
            }
        });

        bAnnulerCreation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

    }
}
